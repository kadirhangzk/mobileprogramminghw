package com.alexnevsky.restaurant.tags;

import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.A_HREF_CANCEL_ORDER;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.A_HREF_DELETE_ORDER;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.A_HREF_END;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.BR_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.CAPTION_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.CAPTION_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.COLON_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.COMMA_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.FIELDSET_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.FIELDSET_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.FORM_BOOKING_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.FORM_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.HR_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.INPUT_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.INPUT_SELECT_ROOM_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.INPUT_SUBMIT_SELECT_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.LABEL_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.LABEL_ROOM_ID_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.LEGEND_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.LEGEND_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.LI_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.LI_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.MINUS;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.NUMBER_SIGN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.OPTION_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.OPTION_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.PERIOD_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.P_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.P_START_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.P_SUBMIT_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.SELECT_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.SELECT_ROOM_ID_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.SPACE_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.STRONG_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.STRONG_COLOR_DARKORCHILD_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.STRONG_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TABLE_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TABLE_LIGHT_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TAG_END;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TD_ALT_CLASS;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TD_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TD_CLASS_BEGIN;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TD_EMPTY_CLASS;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TD_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TH_COL_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TH_COL_NO_BG_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TH_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TH_ROW_CLASS_BEGIN;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TH_SPEC_ALT_CLASS;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TH_SPEC_CLASS;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TR_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.TR_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.UL_CLASS_LINK_BEGIN_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.UL_END_HTML_TAG;
import static com.alexnevsky.restaurant.tags.helpers.HTMLHelper.VERTICAL_BAR_HTML_TAG;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import com.alexnevsky.restaurant.controller.Controller;
import com.alexnevsky.restaurant.dao.AbstractDAOFactory;
import com.alexnevsky.restaurant.dao.CreditCardDAO;
import com.alexnevsky.restaurant.dao.CustomerDAO;
import com.alexnevsky.restaurant.dao.FormDAO;
import com.alexnevsky.restaurant.dao.OrderDAO;
import com.alexnevsky.restaurant.dao.RoomDAO;
import com.alexnevsky.restaurant.dao.exception.DAOException;
import com.alexnevsky.restaurant.manager.AttributesManager;
import com.alexnevsky.restaurant.manager.MessageManager;
import com.alexnevsky.restaurant.model.CreditCard;
import com.alexnevsky.restaurant.model.Customer;
import com.alexnevsky.restaurant.model.Form;
import com.alexnevsky.restaurant.model.Order;
import com.alexnevsky.restaurant.model.Room;
import com.alexnevsky.restaurant.model.enums.OrderStatusEnum;
import com.alexnevsky.restaurant.model.enums.RoomClassEnum;

/**
 * Free Rooms List JSP Custom Tag.
 * 
 * @version 1.0 06.06.2011
 * @author Alex Nevsky
 */
public class FreeTableListTag extends TagSupport {

	static {
		logger = Logger.getLogger(FreeTableListTag.class);
	}
	private static final long serialVersionUID = 1L;
	private static Logger logger;
	private Long orderId;

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Provides logics for custom tag.
	 */
	@Override
	public int doStartTag() throws JspException {
		JspWriter out = this.pageContext.getOut();
		try {
			String dataToView = this.getData();
			out.write(dataToView);
		} catch (IOException e) {
			logger.warn(e, e);
		} catch (Exception e) {
			logger.error(e, e);
		}
		return SKIP_BODY;
	}

	private String getData() {
		String dataToView = null;

		Customer customer = null;
		CreditCard creditCard = null;
		Order order = null;
		Form form = null;
		Table orderTable = null;
		List<Table> freeTableList = null;

		try {
			AbstractDAOFactory daoFactory = Controller.getDAOFactory();

			OrderDAO orderDAO = daoFactory.getOrderDAO();
			FormDAO formDAO = daoFactory.getFormDAO();
			CustomerDAO customerDAO = daoFactory.getCustomerDAO();
			TableDAO TableDAO = daoFactory.getTableDAO();
			CreditCardDAO creditCardDAO = daoFactory.getCreditCardDAO();

			order = orderDAO.find(this.orderId);
			form = formDAO.find(order.getFormId());

			freeTableList = this.getFreeTables(form);

			customer = customerDAO.find(order.getCustomerId());
			creditCard = creditCardDAO.find(customer.getCreditCardNumber());

			Long orderTableId = order.getTableId();

			Long formId = order.getFormId();
			form = formDAO.find(formId);

			orderTable = TableDAO.find(orderTableId);
		} catch (DAOException ex) {
			logger.error(ex, ex);
			return MessageManager.DAO_EXCEPTION_ERROR_MESSAGE;
		}

		dataToView = this.generateHTML(freeTableList, order, customer, creditCard, form, orderTable);

		return dataToView;
	}

	private List<Table> getFreeTables(Form form) throws DAOException {
		List<Table> freeTableList = null;

		AbstractDAOFactory daoFactory = Controller.getDAOFactory();

		OrderDAO orderDAO = daoFactory.getOrderDAO();
		FormDAO formDAO = daoFactory.getFormDAO();
		RoomDAO roomDAO = daoFactory.getTabşeDAO();

		Date arrival = form.getArrival();
		Integer nights = form.getNights();
		Date departure = this.getDepartureDate(arrival, nights);

		Integer adult = form.getAdult();
		Integer child = form.getChild();
		TableClassEnum TableClass = form.getTableClass();

		List<Table> TabşeParamList = null;
		TabşeParamList = tableDAO.list(adult, child, tableClass);

		List<Table> notFreeTableList = new ArrayList<Tabşe>();

		for (Table Table : tableParamList) {
			List<Order> orderWithParamTableList = null;
			orderWithParamTableList = orderDAO.listWhereTableAndStatus(table.getId(), OrderStatusEnum.CHECKED);

			for (Order orderTmp : orderWithParamTablemList) {
				Form formTmp = null;
				formTmp = formDAO.find(orderTmp.getFormId());

				Date arrivalTmp = formTmp.getArrival();
				Integer nightsTmp = formTmp.getNights();
				Date departureTmp = new Date();
				GregorianCalendar gregorianCalendarTmp = new GregorianCalendar();
				gregorianCalendarTmp.setTime(arrivalTmp);
				gregorianCalendarTmp.add(Calendar.DATE, nightsTmp);
				departureTmp = gregorianCalendarTmp.getTime();
				int after = arrival.compareTo(departureTmp);
				if (!departure.before(arrivalTmp)) {
					notFreeTableList.add(table);
				} else if (after < 0) {
					notFreeTableList.add(table);
				}
			}
		}

		tableParamList.removeAll(notFreeTableList);

		freeTableList = tableParamList;

		return freeTableList;
	}

	private String generateHTML(List<Table> freeTableList, Order order, Customer customer, CreditCard creditCard,
			Form form, Table orderTable) {
		StringBuilder sb = new StringBuilder();

		Locale locale = null;
		String specialUserLocale = (String) this.pageContext.getSession().getAttribute(
				AttributesManager.PARAM_NAME_SPECIAL_USER_LOCALE);
		if (specialUserLocale != null && !specialUserLocale.isEmpty()) {
			locale = new Locale(specialUserLocale);
		} else {
			locale = this.pageContext.getRequest().getLocale();
		}

		String tableClass = form.getTableClass().toString();

		String orderStatus = order.getOrderStatus().toString();

		String commentary = form.getCommentary();

		String firstName = customer.getFirstName();
		String lastName = customer.getLastName();

		sb.append(this.printCustomerAndTableName(firstName, lastName, tableClass, locale));


		sb.append(this.printCustomerTable(customer, form, creditCard, locale));

		sb.append(this.printOrderTable(order, form, orderTable, locale));


		sb.append(this.printAfterTables(tableClass, commentary, this.orderId, orderStatus, locale));


		sb.append(this.printSelectTableForm(freeTableList, locale));


		sb.append(this.printTablesTable(freeTableList, locale));

		return sb.toString();
	}

	private String printCustomerAndRoomName(String firstName, String lastName, String tableClass, Locale locale) {
		StringBuilder sb = new StringBuilder();

		sb.append(P_START_HTML_TAG);
		sb.append(STRONG_COLOR_DARKORCHILD_BEGIN_HTML_TAG);
		sb.append(firstName);
		sb.append(SPACE_HTML_TAG);
		sb.append(lastName);
		sb.append(STRONG_END_HTML_TAG);
		sb.append(COMMA_HTML_TAG);
		sb.append(SPACE_HTML_TAG);
		sb.append(tableClass);
		sb.append(SPACE_HTML_TAG);
		sb.append(this.getMessage(MessageManager.TAG_ROOM, locale));
		sb.append(PERIOD_HTML_TAG);
		sb.append(P_END_HTML_TAG);

		return sb.toString();
	}

	private String printCustomerTable(Customer customer, Form form, CreditCard creditCard, Locale locale) {
		StringBuilder sb = new StringBuilder();

		String thClass = TH_SPEC_ALT_CLASS;
		String tdClass = TD_ALT_CLASS;

		String creditCardType = creditCard.getCardType().toString();
		String creditCardHolderName = creditCard.getHolderName().toString();

		Long customerId = customer.getId();
		String firstName = customer.getFirstName();
		String lastName = customer.getLastName();
		String email = customer.getEmail();
		String phone = customer.getPhone();
		String address = customer.getAddress();
		Long creditCardNumber = customer.getCreditCardNumber();

		sb.append(TABLE_LIGHT_BEGIN_HTML_TAG);
		sb.append(CAPTION_BEGIN_HTML_TAG);
		sb.append(this.getMessage(MessageManager.TAG_CUSTOMERS_INFO, locale));
		sb.append(CAPTION_END_HTML_TAG);

		sb.append(TR_BEGIN_HTML_TAG);
		sb.append(TH_COL_NO_BG_HTML_TAG);
		sb.append(this.getMessage(MessageManager.TAG_ID, locale));
		sb.append(TH_END_HTML_TAG);
		sb.append(TH_COL_HTML_TAG);
		sb.append(this.getMessage(MessageManager.TAG_FIRST_NAME, locale));
		sb.append(TH_END_HTML_TAG);
		sb.append(TH_COL_HTML_TAG);
		sb.append(this.getMessage(MessageManager.TAG_LAST_NAME, locale));
		sb.append(TH_END_HTML_TAG);
		sb.append(TH_COL_HTML_TAG);
		sb.append(this.getMessage(MessageManager.TAG_EMAIL, locale));
		sb.append(TH_END_HTML_TAG);
		sb.append(TH_COL_HTML_TAG);
		sb.append(this.getMessage(MessageManager.TAG_PHONE, locale));
		sb.append(TH_END_HTML_TAG);
		sb.append(TR_END_HTML_TAG);

		sb.append(TR_BEGIN_HTML_TAG);
		sb.append(TH_ROW_CLASS_BEGIN);
		sb.append(thClass);
		sb.append(TAG_END);
		sb.append(customerId);
		sb.append(TH_END_HTML_TAG);
		sb.append(TD_CLASS_BEGIN);
		sb.append(tdClass);
		sb.append(TAG_END);
		sb.append(firstName);
		sb.append(TD_END_HTML_TAG);
		sb.append(TD_CLASS_BEGIN);
		sb.append(tdClass);
		sb.append(TAG_END);
		sb.append(lastName);
		sb.append(TD_END_HTML_TAG);
		sb.append(TD_CLASS_BEGIN);
		sb.append(tdClass);
		sb.append(TAG_END);
		sb.append(email);
		sb.append(TD_END_HTML_TAG);
		sb.append(TD_CLASS_BEGIN);
		sb.append(tdClass);
		sb.append(TAG_END);
		sb.append(phone);
		sb.append(TD_END_HTML_TAG);
		sb.append(TR_END_HTML_TAG);

		sb.append(TABLE_END_HTML_TAG);
		sb.append(BR_HTML_TAG);

		sb.append(UL_CLASS_LINK_BEGIN_HTML_TAG);

		sb.append(LI_BEGIN_HTML_TAG);
		sb.append(STRONG_BEGIN_HTML_TAG);
		sb.append(this.getMessage(MessageManager.TAG_ADDRESS, locale));
		sb.append(COLON_HTML_TAG);
		sb.append(STRONG_END_HTML_TAG);
		sb.append(SPACE_HTML_TAG);
		sb.append(address);
		sb.append(LI_END_HTML_TAG);

		sb.append(LI_BEGIN_HTML_TAG);
		sb.append(STRONG_BEGIN_HTML_TAG);
		sb.append(this.getMessage(MessageManager.TAG_CREDIT_CARD, locale));
		sb.append(COLON_HTML_TAG);
		sb.append(STRONG_END_HTML_TAG);
		sb.append(SPACE_HTML_TAG);
		sb.append(creditCardType);
		sb.append(COMMA_HTML_TAG);
		sb.append(SPACE_HTML_TAG);
		sb.append(NUMBER_SIGN_HTML_TAG);
		sb.append(creditCardNumber);
		sb.append(COMMA_HTML_TAG);
		sb.append(SPACE_HTML_TAG);
		sb.append(creditCardHolderName);
		sb.append(LI_END_HTML_TAG);

		sb.append(UL_END_HTML_TAG);
		sb.append(BR_HTML_TAG);

		return sb.toString();
	}

		}
	}
}
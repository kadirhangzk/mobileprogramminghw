package com.alexnevsky.restaurant.model;

import com.alexnevsky.restaurant.model.enums.TableClassEnum;


public class Table implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private Integer adultMax;
	private Integer childMax;
	private TableClassEnum tableClass;
	private Double nightPrice;


	public Table() {
	}


	public Table(Long id, Integer adultMax, Integer childMax, TableClassEnum tableClass, Double nightPrice) {
		this.id = id;
		this.adultMax = adultMax;
		this.childMax = childMax;
		this.tableClass = tableClass;
		this.nightPrice = nightPrice;
	}


	public Integer getAdultMax() {
		return this.adultMax;
	}


	public Integer getChildMax() {
		return this.childMax;
	}


	public Long getId() {
		return this.id;
	}


	public Double getNightPrice() {
		return this.nightPrice;
	}


	public tableClassEnum getRoomClass() {
		return this.tableClass;
	}


	public void setAdultMax(Integer adultMax) {
		this.adultMax = adultMax;
	}


	public void setChildMax(Integer childMax) {
		this.childMax = childMax;
	}


	public void setId(Long id) {
		this.id = id;
	}



	}
}
